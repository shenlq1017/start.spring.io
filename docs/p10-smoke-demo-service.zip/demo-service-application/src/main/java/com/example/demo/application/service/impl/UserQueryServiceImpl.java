package com.example.demo.application.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.application.service.UserQueryService;
import com.example.demo.contract.common.page.PageResult;
import com.example.demo.contract.dto.request.QueryUserRequest;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.contract.dto.response.UserSummaryResponse;
import com.example.demo.domain.exception.UserNotFoundException;
import com.example.demo.infrastructure.persistence.mapper.UserReadMapper;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 用户 查询服务（读侧 CQRS：ReadMapper 投影，不经领域对象）
 */
@Service
@Transactional(readOnly = true)
public class UserQueryServiceImpl implements UserQueryService {

	private final UserReadMapper userReadMapper;

	public UserQueryServiceImpl(UserReadMapper userReadMapper) {
		this.userReadMapper = userReadMapper;
	}

	@Override
	public UserDetailResponse detail(String id) {
		UserDetailResponse detail = userReadMapper.selectDetailById(id);
		if (detail == null) {
			throw new UserNotFoundException(id);
		}
		return detail;
	}

	@Override
	public PageResult<UserSummaryResponse> page(QueryUserRequest query) {
		Page<UserSummaryResponse> page = Page.of(query.current(), query.size());
		return PageResult.of(
				userReadMapper.selectSummaryPage(page, query).getRecords(),
				page.getTotal(),
				page.getCurrent(),
				page.getSize());
	}

}
