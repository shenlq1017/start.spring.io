package com.example.demo.application.service;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.annotation.ExcelProperty;

import org.springframework.stereotype.Service;

/**
 * 用户 导入/导出（EasyExcel skeleton — compiles; wire business mapping next）.
 */
@Service
public class UserImportExportService {

	public java.util.Map<String, Object> importData(org.springframework.web.multipart.MultipartFile file)
			throws java.io.IOException {
		if (file == null || file.isEmpty()) {
			return java.util.Map.of("accepted", false, "message", "empty upload");
		}
		java.util.List<UserExcelRow> rows = EasyExcel.read(file.getInputStream())
				.head(UserExcelRow.class)
				.sheet()
				.doReadSync();
		// Wire rows to CreateUserRequest / ApplicationService.create as needed
		return java.util.Map.of("accepted", true, "count", rows.size());
	}

	public void exportData(jakarta.servlet.http.HttpServletResponse response) throws java.io.IOException {
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setCharacterEncoding("utf-8");
		response.setHeader("Content-Disposition", "attachment; filename=user.xlsx");
		java.util.List<UserExcelRow> rows = java.util.List.of(); // fill from QueryService
		EasyExcel.write(response.getOutputStream(), UserExcelRow.class).sheet("用户").doWrite(rows);
	}


	/** Excel row DTO for EasyExcel bind */
	public static class UserExcelRow {
		@ExcelProperty("用户名")
		private String username;

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		@ExcelProperty("邮箱")
		private String email;

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		@ExcelProperty("昵称")
		private String nickname;

		public String getNickname() {
			return nickname;
		}

		public void setNickname(String nickname) {
			this.nickname = nickname;
		}


	}

}
