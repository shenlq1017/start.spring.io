package com.example.demo.contract.constant;

/**
 * User API path (Controller + Feign). Convention: /{prefix}/v1/{resource}
 * e.g. /demo/v1/users — module/menu style, not bare /users.
 */
public final class UserApiPath {

	public static final String BASE = "/demo/v1/users";

	private UserApiPath() {
	}

}
