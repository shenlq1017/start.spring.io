package com.example.demo.contract.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;


/**
 * 用户详情
 */
@Schema(description = "用户详情")
public record UserDetailResponse(
		String id,
		@Schema(description = "用户名")
		String username,
		@Schema(description = "邮箱")
		String email,
		@Schema(description = "昵称")
		String nickname,
		String status,
		long version) {
}
