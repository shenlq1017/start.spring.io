/**
 * SnowflakeIdGenerator.
 */
package com.example.demo.contract.common.id;
