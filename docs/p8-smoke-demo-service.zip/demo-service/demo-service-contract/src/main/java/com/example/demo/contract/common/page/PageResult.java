package com.example.demo.contract.common.page;

import java.util.List;

/**
 * Unified page payload (module-local common under contract — no platform common-core).
 * Controllers must return this type; never expose MyBatis-Plus IPage.
 */
public record PageResult<T>(List<T> records, long total, long current, long size) {

	public static <T> PageResult<T> of(List<T> records, long total, long current, long size) {
		return new PageResult<>(records, total, current, size);
	}

}
