package com.example.demo.contract.enums;

/**
 * 用户状态
 */
public enum UserStatusEnum {

	ACTIVE("启用"),
	DISABLED("停用");

	private final String description;

	UserStatusEnum(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

}
