/**
 * Shared contract enums.
 */
package com.example.demo.contract.enums;
