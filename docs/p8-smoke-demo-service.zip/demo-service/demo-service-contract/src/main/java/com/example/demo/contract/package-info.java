/**
 * API contracts and DTOs (zero Spring runtime dependencies).
 */
package com.example.demo.contract;
