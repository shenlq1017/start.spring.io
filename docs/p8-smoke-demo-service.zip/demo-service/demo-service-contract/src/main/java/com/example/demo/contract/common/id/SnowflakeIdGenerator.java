package com.example.demo.contract.common.id;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Snowflake ID generator (no synchronized — virtual-thread friendly).
 * Production: assign workerId via instance index; default workerId=1 for single-node.
 */
public final class SnowflakeIdGenerator {

	private static final long EPOCH = 1700000000000L;
	private static final long SEQUENCE_BITS = 12L;
	private static final long SEQUENCE_MASK = ~(-1L << SEQUENCE_BITS);

	private final long workerId;
	private final AtomicLong lastTimestamp = new AtomicLong(-1L);
	private final AtomicLong sequence = new AtomicLong(0L);

	public SnowflakeIdGenerator() {
		this(1L);
	}

	public SnowflakeIdGenerator(long workerId) {
		this.workerId = workerId & 0x1FL;
	}

	public String nextId() {
		long timestamp = System.currentTimeMillis();
		while (true) {
			long last = lastTimestamp.get();
			long seq;
			if (timestamp == last) {
				seq = sequence.incrementAndGet() & SEQUENCE_MASK;
				if (seq == 0L) {
					timestamp = nextMillis(last);
					continue;
				}
			}
			else {
				sequence.set(0L);
				seq = 0L;
				if (!lastTimestamp.compareAndSet(last, timestamp)) {
					continue;
				}
			}
			long id = ((timestamp - EPOCH) << 22) | (workerId << 12) | seq;
			return String.valueOf(id);
		}
	}

	private long nextMillis(long last) {
		long timestamp = System.currentTimeMillis();
		while (timestamp <= last) {
			timestamp = System.currentTimeMillis();
		}
		return timestamp;
	}

}
