/**
 * API path and service name constants.
 */
package com.example.demo.contract.constant;
