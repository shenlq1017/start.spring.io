package com.example.demo.contract.constant;

public final class UserServiceName {

	public static final String NAME = "demo-service";

	private UserServiceName() {
	}

}
