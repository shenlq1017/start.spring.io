package com.example.demo.contract.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;


/**
 * 创建用户请求
 */
@Schema(description = "创建用户请求")
public record CreateUserRequest(
		@NotBlank(message = "用户名不能为空")
		@Size(max = 255)
		@Schema(description = "用户名", requiredMode = Schema.RequiredMode.REQUIRED)
		String username,
		@Size(max = 255)
		@Schema(description = "邮箱")
		String email,
		@Size(max = 255)
		@Schema(description = "昵称")
		String nickname) {
}
