/**
 * Module-local PageResult (skill common-core spirit).
 */
package com.example.demo.contract.common.page;
