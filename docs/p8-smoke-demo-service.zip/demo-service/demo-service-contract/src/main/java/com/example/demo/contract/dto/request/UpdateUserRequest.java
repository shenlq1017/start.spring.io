package com.example.demo.contract.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;


/**
 * 更新用户请求
 */
@Schema(description = "更新用户请求")
public record UpdateUserRequest(
		@Size(max = 255)
		@Schema(description = "用户名")
		String username,
		@Size(max = 255)
		@Schema(description = "邮箱")
		String email,
		@Size(max = 255)
		@Schema(description = "昵称")
		String nickname) {
}
