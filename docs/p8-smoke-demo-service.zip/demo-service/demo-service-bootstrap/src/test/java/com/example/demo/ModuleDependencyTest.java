package com.example.demo;

import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

/**
 * Architecture guardrails for the six-module layout.
 */
@AnalyzeClasses(packages = "com.example.demo")
class ModuleDependencyTest {

	@ArchTest
	static final ArchRule domainMustNotDependOnFrameworks = noClasses().that()
		.resideInAPackage("..domain..")
		.should()
		.dependOnClassesThat()
		.resideInAnyPackage("org.springframework..", "com.baomidou..", "tools.jackson..", "com.fasterxml..");

	@ArchTest
	static final ArchRule contractMustNotDependOnSpring = noClasses().that()
		.resideInAPackage("..contract..")
		.should()
		.dependOnClassesThat()
		.resideInAPackage("org.springframework..");

	@ArchTest
	static final ArchRule banLegacyJackson = noClasses().should()
		.dependOnClassesThat()
		.resideInAPackage("com.fasterxml.jackson..");

	@ArchTest
	static final ArchRule domainMustNotDependOnInfrastructure = noClasses().that()
		.resideInAPackage("..domain..")
		.should()
		.dependOnClassesThat()
		.resideInAPackage("..infrastructure..");

}
