package com.example.demo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * demo-service bootstrap entry point.
 * <p>
 * scanBasePackages stays on this service package; shared platform starters (Phase B)
 * should register via {@code AutoConfiguration.imports}, not component scan.
 */
@SpringBootApplication(scanBasePackages = "com.example.demo")
@MapperScan("com.example.demo.infrastructure.persistence.mapper")
public class DemoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoServiceApplication.class, args);
	}

}
