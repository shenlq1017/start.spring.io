-- 用户
CREATE TABLE sys_user (
    id             VARCHAR(64)  PRIMARY KEY,
    username      VARCHAR(255) NOT NULL,
    email         VARCHAR(255),
    nickname      VARCHAR(255),
    status         VARCHAR(32)  NOT NULL,
    version        INT          NOT NULL DEFAULT 0,
    deleted        BOOLEAN      NOT NULL DEFAULT FALSE,
    create_time    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    update_time    TIMESTAMPTZ
);
CREATE UNIQUE INDEX uk_sys_user_username ON sys_user (username);
CREATE INDEX idx_sys_user_status ON sys_user (status);
COMMENT ON TABLE  sys_user IS '用户表';
COMMENT ON COLUMN sys_user.id IS '主键（Snowflake）';
COMMENT ON COLUMN sys_user.username IS '用户名';
COMMENT ON COLUMN sys_user.email IS '邮箱';
COMMENT ON COLUMN sys_user.nickname IS '昵称';
COMMENT ON COLUMN sys_user.status IS '状态';
COMMENT ON COLUMN sys_user.version IS '乐观锁版本号';
COMMENT ON COLUMN sys_user.deleted IS '删除标记';
COMMENT ON COLUMN sys_user.create_time IS '创建时间';
COMMENT ON COLUMN sys_user.update_time IS '更新时间';
