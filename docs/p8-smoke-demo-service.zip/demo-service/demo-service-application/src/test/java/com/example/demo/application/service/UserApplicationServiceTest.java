package com.example.demo.application.service;

import com.example.demo.application.assembler.UserAssembler;
import com.example.demo.contract.common.id.SnowflakeIdGenerator;
import com.example.demo.contract.dto.request.CreateUserRequest;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.domain.model.User;
import com.example.demo.domain.query.UserQuery;
import com.example.demo.domain.query.PageSlice;
import com.example.demo.domain.repository.UserRepository;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit test with in-memory fake repository (no Spring context).
 */
class UserApplicationServiceTest {

	@Test
	void createPersistsViaRepository() {
		FakeUserRepository repo = new FakeUserRepository();
		UserApplicationService service = new UserApplicationService(repo, new UserAssembler(),
				new SnowflakeIdGenerator(1L));
		CreateUserRequest request = new CreateUserRequest("demo", "a@b.c", "demo");
		UserDetailResponse detail = service.create(request);
		assertThat(detail.id()).isNotBlank();
		assertThat(repo.store).containsKey(detail.id());
	}

	static final class FakeUserRepository implements UserRepository {

		final Map<String, User> store = new HashMap<>();

		@Override
		public User save(User aggregate) {
			store.put(aggregate.getId(), aggregate);
			return aggregate;
		}

		@Override
		public Optional<User> findById(String id) {
			return Optional.ofNullable(store.get(id));
		}

		@Override
		public void deleteById(String id) {
			store.remove(id);
		}

		@Override
		public PageSlice<User> findPage(UserQuery query, long current, long size) {
			return PageSlice.of(store.values().stream().toList(), store.size());
		}

	}

}
