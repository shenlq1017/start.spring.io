package com.example.demo.application.advice;

import com.example.demo.domain.exception.BusinessException;
import com.example.demo.domain.exception.UserNotFoundException;

import java.net.URI;
import java.time.Instant;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.context.request.WebRequest;

/**
 * Problem Details (RFC 7807) — no global ApiResponse/R wrapper.
 * Maps BusinessException hierarchy + validation failures.
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String ERROR_TYPE_BASE = "https://api.example.com/errors/";

	@ExceptionHandler(BusinessException.class)
	public ProblemDetail handleBusiness(BusinessException ex) {
		HttpStatus status = HttpStatus.resolve(ex.status());
		if (status == null) {
			status = HttpStatus.BAD_REQUEST;
		}
		ProblemDetail detail = ProblemDetail.forStatusAndDetail(status, ex.getMessage());
		detail.setType(URI.create(ERROR_TYPE_BASE + ex.errorType()));
		detail.setTitle("Business error");
		detail.setProperty("timestamp", Instant.now());
		return detail;
	}

	@ExceptionHandler(UserNotFoundException.class)
	public ProblemDetail handleNotFound(UserNotFoundException ex) {
		ProblemDetail detail = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
		detail.setType(URI.create(ERROR_TYPE_BASE + ex.errorType()));
		detail.setTitle("Resource not found");
		detail.setProperty("id", ex.getId());
		detail.setProperty("timestamp", Instant.now());
		return detail;
	}

	@Override
	@Nullable
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		ProblemDetail detail = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST,
				"Validation failed");
		detail.setType(URI.create(ERROR_TYPE_BASE + "validation"));
		detail.setTitle("Validation failed");
		detail.setProperty("timestamp", Instant.now());
		detail.setProperty("errors", ex.getBindingResult().getFieldErrors().stream()
				.map(fe -> fe.getField() + ": " + fe.getDefaultMessage()).toList());
		return ResponseEntity.badRequest().body(detail);
	}

}
