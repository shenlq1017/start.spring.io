/**
 * Exception advice / Problem Details.
 */
package com.example.demo.application.advice;
