package com.example.demo.application.service;

import com.example.demo.application.assembler.UserAssembler;
import com.example.demo.contract.common.id.SnowflakeIdGenerator;
import com.example.demo.contract.dto.request.CreateUserRequest;
import com.example.demo.contract.dto.request.UpdateUserRequest;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.domain.exception.UserNotFoundException;
import com.example.demo.domain.model.User;
import com.example.demo.domain.repository.UserRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 用户 应用服务（写侧编排；ID = Snowflake）
 */
@Service
public class UserApplicationService {

	private final UserRepository repository;
	private final UserAssembler assembler;
	private final SnowflakeIdGenerator idGenerator;

	public UserApplicationService(UserRepository repository, UserAssembler assembler,
			SnowflakeIdGenerator idGenerator) {
		this.repository = repository;
		this.assembler = assembler;
		this.idGenerator = idGenerator;
	}

	@Transactional(rollbackFor = Exception.class)
	public UserDetailResponse create(CreateUserRequest request) {
		String id = idGenerator.nextId();
		User aggregate = User.create(assembler.toCreateCommand(request, id));
		User saved = repository.save(aggregate);
		return assembler.toDetailResponse(saved);
	}

	@Transactional(rollbackFor = Exception.class)
	public UserDetailResponse update(String id, UpdateUserRequest request) {
		User aggregate = repository.findById(id)
			.orElseThrow(() -> new UserNotFoundException(id));
		aggregate.update(assembler.toUpdateCommand(request));
		return assembler.toDetailResponse(repository.save(aggregate));
	}

	@Transactional(rollbackFor = Exception.class)
	public void delete(String id) {
		repository.findById(id).orElseThrow(() -> new UserNotFoundException(id));
		repository.deleteById(id);
	}

}
