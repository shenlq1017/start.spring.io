package com.example.demo.application.assembler;

import com.example.demo.contract.dto.request.CreateUserRequest;
import com.example.demo.contract.dto.request.UpdateUserRequest;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.contract.dto.response.UserSummaryResponse;
import com.example.demo.domain.command.CreateUserCommand;
import com.example.demo.domain.command.UpdateUserCommand;
import com.example.demo.domain.model.User;

import org.springframework.stereotype.Component;

@Component
public class UserAssembler {

	public CreateUserCommand toCreateCommand(CreateUserRequest request, String id) {
		return new CreateUserCommand(id,
				request.username(),
				request.email(),
				request.nickname());
	}

	public UpdateUserCommand toUpdateCommand(UpdateUserRequest request) {
		return new UpdateUserCommand(
				request.username(),
				request.email(),
				request.nickname());
	}

	public UserDetailResponse toDetailResponse(User entity) {
		return new UserDetailResponse(
				entity.getId(),
				entity.getUsername(),
				entity.getEmail(),
				entity.getNickname(),
				entity.getStatus().name(),
				entity.getVersion());
	}

	public UserSummaryResponse toSummaryResponse(User entity) {
		return new UserSummaryResponse(
				entity.getId(),
				entity.getUsername(),
				entity.getEmail(),
				entity.getNickname(),
				entity.getStatus().name());
	}

}
