package com.example.demo.feign;

import com.example.demo.contract.common.page.PageResult;
import com.example.demo.contract.dto.request.CreateUserRequest;
import com.example.demo.contract.dto.request.QueryUserRequest;
import com.example.demo.contract.dto.request.UpdateUserRequest;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.contract.dto.response.UserSummaryResponse;

import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

@Component
public class UserFeignFallbackFactory implements FallbackFactory<UserFeignClient> {

	@Override
	public UserFeignClient create(Throwable cause) {
		return new UserFeignClient() {
			@Override
			public PageResult<UserSummaryResponse> page(QueryUserRequest query) {
				return PageResult.of(java.util.List.of(), 0, 1, 20);
			}

			@Override
			public UserDetailResponse detail(String id) {
				return null;
			}

			@Override
			public UserDetailResponse create(CreateUserRequest request) {
				return null;
			}

			@Override
			public UserDetailResponse update(String id, UpdateUserRequest request) {
				return null;
			}

			@Override
			public void delete(String id) {
			}
		};
	}

}
