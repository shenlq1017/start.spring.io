package com.example.demo.feign;

import com.example.demo.contract.common.page.PageResult;
import com.example.demo.contract.constant.UserApiPath;
import com.example.demo.contract.constant.UserServiceName;
import com.example.demo.contract.dto.request.CreateUserRequest;
import com.example.demo.contract.dto.request.QueryUserRequest;
import com.example.demo.contract.dto.request.UpdateUserRequest;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.contract.dto.response.UserSummaryResponse;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * 用户 Feign client — mirrors Controller paths/signatures.
 */
@FeignClient(name = UserServiceName.NAME, path = UserApiPath.BASE,
		fallbackFactory = UserFeignFallbackFactory.class)
public interface UserFeignClient {

	@GetMapping
	PageResult<UserSummaryResponse> page(@Validated QueryUserRequest query);

	@GetMapping("/{id}")
	UserDetailResponse detail(@PathVariable("id") String id);

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	UserDetailResponse create(@RequestBody @Validated CreateUserRequest request);

	@PutMapping("/{id}")
	UserDetailResponse update(@PathVariable("id") String id,
			@RequestBody @Validated UpdateUserRequest request);

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	void delete(@PathVariable("id") String id);

}
