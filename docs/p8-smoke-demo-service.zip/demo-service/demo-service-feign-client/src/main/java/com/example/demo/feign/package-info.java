/**
 * Feign clients and fallback factories.
 */
package com.example.demo.feign;
