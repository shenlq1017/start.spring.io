package com.example.demo.infrastructure.persistence.converter;

import com.example.demo.domain.model.User;
import com.example.demo.domain.model.UserStatus;
import com.example.demo.infrastructure.persistence.entity.UserPO;

import org.springframework.stereotype.Component;

@Component
public class UserConverter {

	public UserPO toPO(User entity) {
		UserPO po = new UserPO();
		po.setId(entity.getId());
		po.setUsername(entity.getUsername());
		po.setEmail(entity.getEmail());
		po.setNickname(entity.getNickname());
		po.setStatus(entity.getStatus().name());
		po.setVersion(entity.getVersion());
		po.setCreateTime(entity.getCreateTime());
		po.setUpdateTime(entity.getUpdateTime());
		return po;
	}

	public User toDomain(UserPO po) {
		return User.restore(
				po.getId(),
				po.getUsername(),
				po.getEmail(),
				po.getNickname(),
				UserStatus.valueOf(po.getStatus()),
				po.getVersion() == null ? 0L : po.getVersion(),
				po.getCreateTime(),
				po.getUpdateTime());
	}

}
