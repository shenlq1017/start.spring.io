/**
 * Persistence objects (PO).
 */
package com.example.demo.infrastructure.persistence.entity;
