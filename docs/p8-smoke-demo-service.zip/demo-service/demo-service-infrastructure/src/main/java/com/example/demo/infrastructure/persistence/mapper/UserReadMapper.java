package com.example.demo.infrastructure.persistence.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.contract.dto.request.QueryUserRequest;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.contract.dto.response.UserSummaryResponse;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 读侧 Mapper（CQRS 查询投影，直接出 DTO）
 */
@Mapper
public interface UserReadMapper {

	UserDetailResponse selectDetailById(@Param("id") String id);

	IPage<UserSummaryResponse> selectSummaryPage(Page<?> page, @Param("query") QueryUserRequest query);

}
