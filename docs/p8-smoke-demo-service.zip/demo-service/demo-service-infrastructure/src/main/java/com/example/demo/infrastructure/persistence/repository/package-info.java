/**
 * Repository adapters.
 */
package com.example.demo.infrastructure.persistence.repository;
