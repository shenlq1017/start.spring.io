/**
 * MyBatis mappers.
 */
package com.example.demo.infrastructure.persistence.mapper;
