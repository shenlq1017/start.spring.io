package com.example.demo.infrastructure.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.domain.model.User;
import com.example.demo.domain.query.UserQuery;
import com.example.demo.domain.query.PageSlice;
import com.example.demo.domain.repository.UserRepository;
import com.example.demo.infrastructure.persistence.converter.UserConverter;
import com.example.demo.infrastructure.persistence.entity.UserPO;
import com.example.demo.infrastructure.persistence.mapper.UserMapper;

import java.util.Optional;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

@Repository
public class UserRepositoryImpl implements UserRepository {

	private final UserMapper userMapper;
	private final UserConverter userConverter;

	public UserRepositoryImpl(UserMapper userMapper, UserConverter userConverter) {
		this.userMapper = userMapper;
		this.userConverter = userConverter;
	}

	@Override
	public User save(User aggregate) {
		UserPO po = userConverter.toPO(aggregate);
		UserPO existing = userMapper.selectById(po.getId());
		if (existing == null) {
			if (po.getVersion() == null) {
				po.setVersion(0L);
			}
			userMapper.insert(po);
		}
		else {
			if (po.getVersion() == null) {
				po.setVersion(existing.getVersion());
			}
			userMapper.updateById(po);
		}
		UserPO saved = userMapper.selectById(po.getId());
		return userConverter.toDomain(saved != null ? saved : po);
	}

	@Override
	public Optional<User> findById(String id) {
		UserPO po = userMapper.selectById(id);
		return Optional.ofNullable(po).map(userConverter::toDomain);
	}

	@Override
	public void deleteById(String id) {
		userMapper.deleteById(id);
	}

	@Override
	public PageSlice<User> findPage(UserQuery query, long current, long size) {
		Page<UserPO> page = Page.of(current, size);
		LambdaQueryWrapper<UserPO> wrapper = buildWrapper(query);
		wrapper.orderByDesc(UserPO::getCreateTime);
		Page<UserPO> result = userMapper.selectPage(page, wrapper);
		return PageSlice.of(
				result.getRecords().stream().map(userConverter::toDomain).toList(),
				result.getTotal());
	}

	private LambdaQueryWrapper<UserPO> buildWrapper(UserQuery query) {
		LambdaQueryWrapper<UserPO> wrapper = new LambdaQueryWrapper<>();
		if (query != null && StringUtils.hasText(query.status())) {
			wrapper.eq(UserPO::getStatus, query.status());
		}
		return wrapper;
	}

}
