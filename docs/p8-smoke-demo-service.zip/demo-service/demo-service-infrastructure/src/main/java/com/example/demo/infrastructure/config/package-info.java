/**
 * Infrastructure Spring configuration.
 */
package com.example.demo.infrastructure.config;
