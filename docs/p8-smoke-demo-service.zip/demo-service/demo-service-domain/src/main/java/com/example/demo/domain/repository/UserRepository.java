package com.example.demo.domain.repository;

import com.example.demo.domain.model.User;
import com.example.demo.domain.query.UserQuery;
import com.example.demo.domain.query.PageSlice;

import java.util.Optional;

public interface UserRepository {

	User save(User aggregate);

	Optional<User> findById(String id);

	void deleteById(String id);

	PageSlice<User> findPage(UserQuery query, long current, long size);

}
