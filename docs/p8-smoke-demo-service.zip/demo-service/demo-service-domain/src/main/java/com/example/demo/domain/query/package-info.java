/**
 * Domain queries.
 */
package com.example.demo.domain.query;
