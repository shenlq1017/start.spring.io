package com.example.demo.domain.query;

import java.util.List;

/**
 * Domain-layer page slice (no MyBatis-Plus IPage leak into domain).
 */
public record PageSlice<T>(List<T> records, long total) {

	public static <T> PageSlice<T> of(List<T> records, long total) {
		return new PageSlice<>(records, total);
	}

}
