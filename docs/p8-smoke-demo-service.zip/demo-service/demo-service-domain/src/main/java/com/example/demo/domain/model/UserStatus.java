package com.example.demo.domain.model;

public enum UserStatus {

	ACTIVE, DISABLED

}
