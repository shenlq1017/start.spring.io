/**
 * Domain events.
 */
package com.example.demo.domain.event;
