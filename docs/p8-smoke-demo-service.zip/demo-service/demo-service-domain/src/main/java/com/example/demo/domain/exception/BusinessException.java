package com.example.demo.domain.exception;

/**
 * Business exception base — errorType feeds Problem Detail type URI; status is HTTP code.
 */
public abstract class BusinessException extends RuntimeException {

	protected BusinessException(String message) {
		super(message);
	}

	public abstract String errorType();

	public abstract int status();

}
