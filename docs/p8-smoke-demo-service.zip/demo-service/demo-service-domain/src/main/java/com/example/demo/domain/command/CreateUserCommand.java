package com.example.demo.domain.command;


public record CreateUserCommand(
		String id,
		String username,
		String email,
		String nickname) {
}
