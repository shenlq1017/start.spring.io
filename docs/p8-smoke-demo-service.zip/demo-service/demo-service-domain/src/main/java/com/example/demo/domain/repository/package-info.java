/**
 * Domain repository ports.
 */
package com.example.demo.domain.repository;
