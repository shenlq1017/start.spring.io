/**
 * Domain aggregates and value objects.
 */
package com.example.demo.domain.model;
