package com.example.demo.domain.command;


public record UpdateUserCommand(
		String username,
		String email,
		String nickname) {
}
