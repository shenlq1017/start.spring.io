package com.example.demo.domain.exception;

public class UserNotFoundException extends BusinessException {

	private final String id;

	public UserNotFoundException(String id) {
		super("用户 not found: " + id);
		this.id = id;
	}

	public String getId() {
		return id;
	}

	@Override
	public String errorType() {
		return "user-not-found";
	}

	@Override
	public int status() {
		return 404;
	}

}
