package com.example.demo.domain.query;

public record UserQuery(String keyword, String status) {
}
