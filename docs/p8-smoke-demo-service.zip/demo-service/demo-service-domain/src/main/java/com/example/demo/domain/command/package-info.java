/**
 * Domain commands.
 */
package com.example.demo.domain.command;
