package com.example.demo.domain.model;

import com.example.demo.domain.command.CreateUserCommand;
import com.example.demo.domain.command.UpdateUserCommand;

import java.time.OffsetDateTime;


/**
 * 用户聚合根
 */
public class User {

	private String id;
	private String username;
	private String email;
	private String nickname;
	private UserStatus status;
	private long version;
	private OffsetDateTime createTime;
	private OffsetDateTime updateTime;

	private User() {
	}

	public static User create(CreateUserCommand command) {
		User entity = new User();
		entity.id = command.id();
		entity.username = command.username();
		entity.email = command.email();
		entity.nickname = command.nickname();
		entity.status = UserStatus.ACTIVE;
		entity.version = 0L;
		entity.createTime = OffsetDateTime.now();
		return entity;
	}

	public static User restore(String id, String username, String email, String nickname, UserStatus status, long version,
			OffsetDateTime createTime, OffsetDateTime updateTime) {
		User entity = new User();
		entity.id = id;
		entity.username = username;
		entity.email = email;
		entity.nickname = nickname;
		entity.status = status;
		entity.version = version;
		entity.createTime = createTime;
		entity.updateTime = updateTime;
		return entity;
	}

	public void update(UpdateUserCommand command) {
		if (command.username() != null) {
			this.username = command.username();
		}
		if (command.email() != null) {
			this.email = command.email();
		}
		if (command.nickname() != null) {
			this.nickname = command.nickname();
		}
		this.updateTime = OffsetDateTime.now();
	}

	public String getId() {
		return id;
	}

	public String getUsername() {
		return username;
	}

	public String getEmail() {
		return email;
	}

	public String getNickname() {
		return nickname;
	}

	public UserStatus getStatus() {
		return status;
	}

	public long getVersion() {
		return version;
	}

	public OffsetDateTime getCreateTime() {
		return createTime;
	}

	public OffsetDateTime getUpdateTime() {
		return updateTime;
	}

}
