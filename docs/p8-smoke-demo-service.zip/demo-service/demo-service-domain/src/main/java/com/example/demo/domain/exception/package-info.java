/**
 * Domain exceptions.
 */
package com.example.demo.domain.exception;
