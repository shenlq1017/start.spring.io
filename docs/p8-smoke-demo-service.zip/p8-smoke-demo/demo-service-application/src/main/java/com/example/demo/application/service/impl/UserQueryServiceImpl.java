package com.example.demo.application.service.impl;

import com.example.demo.application.assembler.UserAssembler;
import com.example.demo.application.service.UserQueryService;
import com.example.demo.contract.dto.request.QueryUserRequest;
import com.example.demo.contract.dto.response.PageResult;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.contract.dto.response.UserSummaryResponse;
import com.example.demo.domain.exception.UserNotFoundException;
import com.example.demo.domain.model.User;
import com.example.demo.domain.query.UserQuery;
import com.example.demo.domain.repository.UserRepository;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 用户 查询服务（读侧，经仓储端口，不直接依赖 infrastructure）
 */
@Service
@Transactional(readOnly = true)
public class UserQueryServiceImpl implements UserQueryService {

	private final UserRepository repository;
	private final UserAssembler assembler;

	public UserQueryServiceImpl(UserRepository repository, UserAssembler assembler) {
		this.repository = repository;
		this.assembler = assembler;
	}

	@Override
	public UserDetailResponse detail(String id) {
		User aggregate = repository.findById(id)
			.orElseThrow(() -> new UserNotFoundException(id));
		return assembler.toDetailResponse(aggregate);
	}

	@Override
	public PageResult<UserSummaryResponse> page(QueryUserRequest query) {
		UserQuery q = new UserQuery(query.keyword(), query.status());
		long total = repository.countByQuery(q);
		List<User> all = repository.findByQuery(q);
		long from = Math.max(0, (query.current() - 1) * query.size());
		List<UserSummaryResponse> records = all.stream()
			.skip(from)
			.limit(query.size())
			.map(assembler::toSummaryResponse)
			.toList();
		return PageResult.of(records, total, query.current(), query.size());
	}

}
