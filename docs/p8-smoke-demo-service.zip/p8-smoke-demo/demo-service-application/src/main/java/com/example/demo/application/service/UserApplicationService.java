package com.example.demo.application.service;

import com.example.demo.application.assembler.UserAssembler;
import com.example.demo.contract.dto.request.CreateUserRequest;
import com.example.demo.contract.dto.request.UpdateUserRequest;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.domain.exception.UserNotFoundException;
import com.example.demo.domain.model.User;
import com.example.demo.domain.repository.UserRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 用户 应用服务（写侧编排）
 */
@Service
public class UserApplicationService {

	private final UserRepository repository;
	private final UserAssembler assembler;

	public UserApplicationService(UserRepository repository, UserAssembler assembler) {
		this.repository = repository;
		this.assembler = assembler;
	}

	@Transactional(rollbackFor = Exception.class)
	public UserDetailResponse create(CreateUserRequest request) {
		String id = java.util.UUID.randomUUID().toString().replace("-", "");
		User aggregate = User.create(assembler.toCreateCommand(request, id));
		User saved = repository.save(aggregate);
		return assembler.toDetailResponse(saved);
	}

	@Transactional(rollbackFor = Exception.class)
	public UserDetailResponse update(String id, UpdateUserRequest request) {
		User aggregate = repository.findById(id)
			.orElseThrow(() -> new UserNotFoundException(id));
		aggregate.update(assembler.toUpdateCommand(request));
		return assembler.toDetailResponse(repository.save(aggregate));
	}

	@Transactional(rollbackFor = Exception.class)
	public void delete(String id) {
		repository.findById(id).orElseThrow(() -> new UserNotFoundException(id));
		repository.deleteById(id);
	}

}
