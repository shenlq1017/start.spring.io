package com.example.demo.application.controller;

import com.example.demo.application.service.UserApplicationService;
import com.example.demo.application.service.UserQueryService;
import com.example.demo.contract.constant.UserApiPath;
import com.example.demo.contract.dto.request.CreateUserRequest;
import com.example.demo.contract.dto.request.QueryUserRequest;
import com.example.demo.contract.dto.request.UpdateUserRequest;
import com.example.demo.contract.dto.response.PageResult;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.contract.dto.response.UserSummaryResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用户接口
 */
@Tag(name = "用户管理")
@RestController
@RequestMapping(UserApiPath.BASE)
public class UserController {

	private final UserApplicationService userApplicationService;
	private final UserQueryService userQueryService;

	public UserController(UserApplicationService userApplicationService,
			UserQueryService userQueryService) {
		this.userApplicationService = userApplicationService;
		this.userQueryService = userQueryService;
	}

	@Operation(summary = "分页查询用户")
	@GetMapping
	public PageResult<UserSummaryResponse> page(QueryUserRequest query) {
		return userQueryService.page(query);
	}

	@Operation(summary = "获取用户详情")
	@GetMapping("/{id}")
	public UserDetailResponse detail(@Parameter(description = "ID") @PathVariable String id) {
		return userQueryService.detail(id);
	}

	@Operation(summary = "创建用户")
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public UserDetailResponse create(@RequestBody @Validated CreateUserRequest request) {
		return userApplicationService.create(request);
	}

	@Operation(summary = "更新用户")
	@PutMapping("/{id}")
	public UserDetailResponse update(@Parameter(description = "ID") @PathVariable String id,
			@RequestBody @Validated UpdateUserRequest request) {
		return userApplicationService.update(id, request);
	}

	@Operation(summary = "删除用户")
	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@Parameter(description = "ID") @PathVariable String id) {
		userApplicationService.delete(id);
	}

}
