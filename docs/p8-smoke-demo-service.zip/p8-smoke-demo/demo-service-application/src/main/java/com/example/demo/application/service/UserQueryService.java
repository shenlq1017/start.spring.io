package com.example.demo.application.service;

import com.example.demo.contract.dto.request.QueryUserRequest;
import com.example.demo.contract.dto.response.PageResult;
import com.example.demo.contract.dto.response.UserDetailResponse;
import com.example.demo.contract.dto.response.UserSummaryResponse;

public interface UserQueryService {

	UserDetailResponse detail(String id);

	PageResult<UserSummaryResponse> page(QueryUserRequest query);

}
