package com.example.demo.application.advice;

import com.example.demo.domain.exception.UserNotFoundException;

import java.net.URI;
import java.time.Instant;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
				import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Problem Details (RFC 7807) — no global ApiResponse/R wrapper.
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String ERROR_TYPE_BASE = "https://api.example.com/errors/";

	@ExceptionHandler(UserNotFoundException.class)
	public ProblemDetail handleNotFound(UserNotFoundException ex) {
		ProblemDetail detail = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
		detail.setType(URI.create(ERROR_TYPE_BASE + "not-found"));
		detail.setTitle("Resource not found");
		detail.setProperty("timestamp", Instant.now());
		return detail;
	}

}
