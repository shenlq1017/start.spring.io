package com.example.demo.contract.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 分页查询用户请求
 */
@Schema(description = "用户查询请求")
public record QueryUserRequest(@Schema(description = "状态") String status, @Schema(description = "关键字") String keyword, @Schema(description = "页码", defaultValue = "1") long current, @Schema(description = "每页大小", defaultValue = "20") long size) {

	public QueryUserRequest {
		if (current < 1) {
			current = 1;
		}
		if (size < 1 || size > 200) {
			size = 20;
		}
	}

}
