package com.example.demo.contract.enums;

/**
 * 用户状态
 */
public enum UserStatusEnum {

	ACTIVE, DISABLED

}
