package com.example.demo.contract.dto.response;

import java.util.List;

/**
 * Unified page payload (no ApiResponse/R wrapper — Problem Details for errors).
 */
public record PageResult<T>(List<T> records, long total, long current, long size) {

	public static <T> PageResult<T> of(List<T> records, long total, long current, long size) {
		return new PageResult<>(records, total, current, size);
	}

}
