package com.example.demo.domain.repository;

import com.example.demo.domain.model.User;
import com.example.demo.domain.query.UserQuery;

import java.util.List;
import java.util.Optional;

public interface UserRepository {

	User save(User aggregate);

	Optional<User> findById(String id);

	void deleteById(String id);

	List<User> findByQuery(UserQuery query);

	long countByQuery(UserQuery query);

}
