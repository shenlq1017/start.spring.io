package com.example.demo.domain.exception;

public class UserNotFoundException extends RuntimeException {

	private final String id;

	public UserNotFoundException(String id) {
		super("用户 not found: " + id);
		this.id = id;
	}

	public String getId() {
		return id;
	}

}
