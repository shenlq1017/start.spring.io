package com.example.demo.feign;

import com.example.demo.contract.dto.response.UserDetailResponse;

import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

@Component
public class UserFeignFallbackFactory implements FallbackFactory<UserFeignClient> {

	@Override
	public UserFeignClient create(Throwable cause) {
		return (id) -> null;
	}

}
