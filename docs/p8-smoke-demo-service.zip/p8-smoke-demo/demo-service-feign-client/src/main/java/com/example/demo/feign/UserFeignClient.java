package com.example.demo.feign;

import com.example.demo.contract.constant.UserApiPath;
import com.example.demo.contract.constant.UserServiceName;
import com.example.demo.contract.dto.response.UserDetailResponse;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * 用户 Feign client (provider-owned contract).
 */
@FeignClient(name = UserServiceName.NAME, path = UserApiPath.BASE,
		fallbackFactory = UserFeignFallbackFactory.class)
public interface UserFeignClient {

	@GetMapping("/{id}")
	UserDetailResponse detail(@PathVariable("id") String id);

}
