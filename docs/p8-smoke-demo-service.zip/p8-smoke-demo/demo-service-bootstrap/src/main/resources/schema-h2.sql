-- H2 smoke schema (Flyway disabled on h2 profile)
-- 用户
CREATE TABLE sys_user (
    id             VARCHAR(64)  PRIMARY KEY,
    username      VARCHAR(255) NOT NULL,
    email         VARCHAR(255),
    nickname      VARCHAR(255),
    status         VARCHAR(32)  NOT NULL,
    version        INT          NOT NULL DEFAULT 0,
    deleted        INT          NOT NULL DEFAULT 0,
    create_time    TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time    TIMESTAMP
);
CREATE UNIQUE INDEX uk_sys_user_username ON sys_user (username);
CREATE INDEX idx_sys_user_status ON sys_user (status);

